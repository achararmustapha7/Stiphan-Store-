Put downloadable files here (APK, ZIP, EXE, etc.).
Then set the Download URL to downloads/filename.ext in the Admin Panel.
