HTML5 games go here. Example: docs/games/my-game/index.html
Then set Play Online URL to games/my-game/index.html in the Admin Panel.
