Store optional images/assets here and reference them with relative URLs.
