# STIPHAN STORE — GitHub Pages

## Upload structure
Keep this structure in the repository root:

```text
docs/
  index.html
  catalog.json
  ads.txt
  404.html
  .nojekyll
  games/
  downloads/
  assets/
```

## GitHub Pages
Settings → Pages → Build and deployment:
- Source: Deploy from a branch
- Branch: `main`
- Folder: `/docs`

## Add games/apps
The Admin Panel is a browser-side catalog editor. GitHub Pages is static, so it cannot securely save admin changes to GitHub for all visitors.

For an HTML5 game, upload its files into `docs/games/<game-name>/` and use a relative Play Online URL such as:
`games/<game-name>/index.html`

For an APK/ZIP/EXE or other file, upload it into `docs/downloads/` and use a relative Download URL such as:
`downloads/my-app.apk`

After changing the catalog, export the catalog JSON and replace `docs/catalog.json` in GitHub.

## Ads
AdSense placement is prepared in the page, but real AdSense requires Google approval and your publisher code. Do not invent or copy a publisher ID. Add the exact line Google gives you to `docs/ads.txt` and the approved AdSense code to the page.

## Important
GitHub Pages is suitable for the static store and web games, but a real shared admin/database, user accounts, upload storage, download counters, and synchronized analytics require a backend service.
